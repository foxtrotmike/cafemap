# -*- coding: utf-8 -*-
"""
Created on Mon Nov 16 11:39:35 2015

@author: Amina Asif
"""
class Instance:
    def __init__(self):
        self.feature_vector=[]
        self.gammas=[]
        self.label=None
        self.c=1.0
